<?php
error_reporting(0);
session_start();
include 'connection.php';
if (!isset($_SESSION["user_id"])) {
    header('location:login.php');
}
// Check if the request is POST
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_SESSION["user_id"];
    $cat_id = $_POST["cat_id"];
    $subject = trim($obj->real_escape_string($_POST["subject"]));
    $description = trim($obj->real_escape_string($_POST["description"]));
    $status = $_POST["status"];
    $city_id = $_POST["city_id"];
    $area_id = $_POST["area_id"];
    $pickadd = trim($obj->real_escape_string($_POST["pickadd"]));
    $time = $_POST["time"];
    $date = date("y/m/d");

    $insert = $obj->Query("INSERT INTO donation_user(cat_id,city_id,area_id,user_id,subject,description,pickadd,date,time,status) VALUES('$cat_id','$city_id','$area_id','$id','$subject','$description','$pickadd','$date','$time','Pending')");
    if ($insert) {
        echo 'success';
    } else {
        echo "error";
    }
// }
?>
