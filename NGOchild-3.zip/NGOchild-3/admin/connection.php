<?php

$obj = new mysqli("localhost","root","","childngo-3");
if($obj->connect_errno!=0)
{
	echo $obj->connect_error;
	exit();
}

?>