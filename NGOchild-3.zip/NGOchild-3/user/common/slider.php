 <div class="slider">
        <!-- Set up your HTML -->
        <div class="owl-carousel ">
            <div class="slider-img">
                <div class="item">
                    <div class="slider-img"><img src="assets/images/slider/slider-3.jpg" alt=""></div>
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-12 col-xs-12 alt">
                                <div class="animated bounceInDown slider-captions">
                                    <h1 class="slider-title text-left p-2">“When one<br> gives, two<br> get happy.”</h1>
                                    <p class="slider-text hidden-xs">Alone we can do so little...<br>together we can do so much.</p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="slider-img"><img src="assets/images/slider/slider-1.jpg" alt=""></div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-12 col-xs-12">
                            <div class="slider-captions">
                                <h1 class="slider-title text-left" >It's time for <br>better help.</h1>
                                <p class="slider-text hidden-xs">“A hand loses nothing by<br>holding other's hand.”
</p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="slider-img"><img src="assets/images/slider/slider-2.jpg" alt=""></div>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-12 col-xs-12">
                            <div class="slider-captions ">
                                <h1 class="slider-title text-left">“A hand <br>loses nothing<br> by holding <br>other's hand.”
</h1>
                                <p class="slider-text hidden-xs">“If you do something nice, do it quietly.”
</p>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>                 
   