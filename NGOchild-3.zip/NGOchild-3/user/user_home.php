 
<?php

session_start();

include 'connection.php';

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Child Adoption | childadoption.com</title>
    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@400;500&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/plugins/slider/css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>

<body>

    <?php include 'common/header.php'; ?>

    <!-- ******************** Slider Starts Here ******************* -->
    <?php include 'common/slider.php'; ?>
    <!--  ************************* About Us Starts Here ************************** -->

    <div class="about-us container-fluid">
        <div class="container">

            <div class="row natur-row no-margin w-100">
                <div class="text-part col-md-6">
                    <h2>About Our Charity</h2>
                    <p>We believe that every act of kindness, no matter how small, has the power to make a big difference. Our mission is to spread love and compassion by providing essential resources such as food and clothing to those in need. Through the generosity of donors and the dedication of volunteers, we strive to create a brighter, more hopeful future for all.</p>
                    <p>Our charity is more than just an organization; we are a community of individuals united by the common goal of making the world a better place.</p>
                    <p>With a commitment to transparency and integrity, we ensure that every donation reaches its intended recipient, making a tangible impact on their lives.</p>
                    <p>Through our various programs and initiatives, we aim to not only meet the immediate needs of individuals and families but also empower them to build a better future for themselves.</p>
                    <p>Join us in our mission to spread hope, love, and compassion to those who need it most. Together, we can make a difference.</p>
                </div>
                <div class="image-part col-md-6">
                    <div class="about-quick-box row">
                        <div class="col-md-6">
                            <div class="about-qcard">
                                <i class="fas fa-user"></i>
                                <p>Becom a Volunteer</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="about-qcard ">
                                <i class="fas fa-search-dollar red"></i>
                                <p>Quick Fundrais</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="about-qcard ">
                                <i class="fas fa-donate yell"></i>
                                <p>Giv Donation</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="about-qcard ">
                                <i class="fas fa-hands-helping blu"></i>
                                <p>Help Someone</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ################# Events Start Here#######################--->
    <section class="events">
        <div class="container">
            <div class="session-title row">
                <h2>Popular Causes</h2>
                <p>Join us in making a difference</p>
            </div>
            <div class="event-row row">
                <div class="col-md-4 col-sm-6">
                    <div class="event-box">
                        <img src="assets/images/events/image_08.jpg" alt="">
                        <h4>Child Education in India</h4>
                        <p class="desic">Help provide quality education to children in Africa, empowering them to build a brighter future for themselves and their communities.</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="event-box">
                        <img src="assets/images/events/image_06.jpg" alt="">
                        <h4>Food and Clothing Drive</h4>
                        <p class="desic">Support our efforts to provide essential food and clothing items to families in need, ensuring they have the basic necessities for a better life.</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="event-box">
                        <img src="assets/images/events/image_04.jpg" alt="">
                        <h4>Disaster Relief Fund</h4>
                        <p class="desic">Donate to our disaster relief fund to help those affected by natural disasters, providing them with immediate assistance and support.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ################# Charity Number Starts Here#######################--->
    <div class="doctor-message">
        <div class="inner-lay">
            <div class="container">
                <div class="row session-title">
                    <h2>Our Achievemtns in Numbers</h2>
                    <p>We can talk for a long time about advantages of our Dental clinic before other medical treatment facilities.
                        But you can read the following facts in order to make sure of all pluses of our clinic:</p>
                </div>
                <div class="row">
                    <div class="col-sm-3 numb">
                        <h3>12+</h3>
                        <span>YEARS OF EXPEREANCE</span>
                    </div>
                    <div class="col-sm-3 numb">
                        <h3>1812+</h3>
                        <span>HAPPY CHILDRENS</span>
                    </div>
                    <div class="col-sm-3 numb">
                        <h3>52+</h3>
                        <span>EVENTS</span>
                    </div>
                    <div class="col-sm-3 numb">
                        <h3>48+</h3>
                        <span>FUNT RAISED</span>
                    </div>
                </div>
            </div>

        </div>

    </div>

    <!--################### Our Team Starts Here #######################--->
    <section class="our-team team-11">
        <div class="container">
            <div class="session-title row">
                <h2>Meet our Team</h2>
                <p>Get to know the passionate individuals behind our organization</p>
            </div>
            <div class="row team-row">
                <div class="col-md-4 col-sm-6">
                    <div class="single-usr">
                        <img src="assets/images/team/women-profile.png" alt="">
                        <div class="det-o">
                            <h4>Snehangi Rupareliya</h4>
                            <p>Team Member</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-usr">
                        <img src="assets/images/team/men-profile.png" alt="">
                        <div class="det-o">
                            <h4>Parth Patoliya</h4>
                            <p>Team Member</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-usr">
                        <img src="assets/images/team/women-profile.png" alt="">
                        <div class="det-o">
                            <h4>Renisha Pipaliya</h4>
                            <p>Team Memberr</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ################# Our Blog Starts Here#######################--->
    <section class="our-blog">
        <div class="container">
            <div class="row session-title">
                <h2>Our Blog</h2>
                <p>Stay updated with our latest news and stories</p>
            </div>
            <div class="blog-row row">
                <div class="col-md-4 col-sm-6">
                    <div class="single-blog">
                        <figure>
                            <img src="assets/images/events/image_04.jpg" alt="">
                        </figure>
                        <div class="blog-detail">
                            <small>By Admin | September 15, 2018</small>
                            <h4>Empowering Women Through Education</h4>
                            <p>Education has the power to transform lives, especially for women in developing countries. Read about our efforts to empower women through education.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-blog">
                        <figure>
                            <img src="assets/images/events/image_05.jpg" alt="">
                        </figure>
                        <div class="blog-detail">
                            <small>By Admin | October 20, 2018</small>
                            <h4>Helping Communities in Times of Need</h4>
                            <p>Communities facing challenges like natural disasters or economic hardships need our support. Learn how we're making a difference in times of need.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="single-blog">
                        <figure>
                            <img src="assets/images/events/image_06.jpg" alt="">
                        </figure>
                        <div class="blog-detail">
                            <small>By Admin | November 25, 2018</small>
                            <h4>Spreading Joy During the Holiday Season</h4>
                            <p>The holiday season is a time for giving and spreading joy. Discover how we're bringing smiles to faces during this special time of year.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'common/footer.php'; ?>


</body>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/plugins/scroll-fixed/jquery-scrolltofixed-min.js"></script>
<script src="assets/plugins/slider/js/owl.carousel.min.js"></script>
<script src="assets/js/script.js"></script>

</html>